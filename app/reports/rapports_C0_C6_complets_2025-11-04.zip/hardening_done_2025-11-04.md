# VERR sansg - ANTI-RÉCIDIVE - 2025-11-04
# PROMPT C6: Verrouillage (anti-récidive)

## 📋 FICHIERS CRÉÉS

### 1. `.env.example`

**Fichier:** `.env.example`

**Contenu (à créer):**
```bash
# Superset Configuration
# ⚠️ IMPORTANT: Ne jamais commiter le fichier .env réel avec la SECRET_KEY
# Utiliser un gestionnaire de secrets pour la production

# Superset Secret Key (NE PAS MODIFIER EN PRODUCTION)
# Format: chaîne aléatoire de 32+ caractères
# SUPERSET_SECRET_KEY=your-secret-key-here

# Superset URL
SUPERSET_URL=http://localhost:8088

# Superset Credentials
SUPERSET_USERNAME=admin
SUPERSET_PASSWORD=admin
```

**Status:** ⚠️ À créer manuellement

---

### 2. `ops/SECRETS.md`

**Fichier:** `ops/SECRETS.md`

**Contenu:**
```markdown
# Gestion des Secrets

## SUPERSET_SECRET_KEY

### ⚠️ CRITIQUE: Ne jamais modifier cette clé en production

La `SUPERSET_SECRET_KEY` est utilisée pour chiffrer les connexions PostgreSQL dans Superset.
Si cette clé change, toutes les connexions DB deviennent non déchiffrables.

### Stockage recommandé

1. **Développement:** Variable d'environnement locale (`.env` - non commitée)
2. **Production:** Gestionnaire de secrets (Azure Key Vault, AWS Secrets Manager, etc.)
3. **Docker:** Variable d'environnement dans `docker-compose.yml` (non commitée)

### Backup de la clé

**IMPORTANT:** Sauvegarder la clé dans un gestionnaire de secrets sécurisé:
- Nom du secret: `superset-secret-key-prod`
- Version: Inclure la date de création
- Accès: Restreint aux administrateurs uniquement

### En cas de perte de clé

1. Ne PAS créer une nouvelle clé (perte des connexions DB)
2. Utiliser le script `scripts/reset_superset_db_connections.py` pour recréer les connexions
3. Voir `reports/reset_db_conns_*.json` pour l'historique
```

**Status:** ⚠️ À créer manuellement dans `ops/`

---

### 3. `CONTRIBUTING.md` (section ajoutée)

**Section à ajouter:**

```markdown
## Fichiers protégés

Les fichiers suivants contiennent des informations sensibles et **NE DOIVENT PAS** être modifiés sans validation:

### Fichiers protégés

- `.env` - Variables d'environnement (secrets)
- `docker-compose*.yml` - Configuration Docker (peut contenir des secrets)
- `superset_config.py` - Configuration Superset (si présent)
- `superset/scripts/*` - Scripts de configuration Superset

### Processus de modification

1. **Ouvrir une issue** pour discuter de la modification
2. **Obtenir l'approbation** d'un administrateur
3. **Tester** en environnement de développement
4. **Documenter** les changements dans `CHANGELOG.md`
5. **Valider** avant déploiement en production

### Validation requise pour

- Modification de `SUPERSET_SECRET_KEY`
- Changement de configuration Docker
- Modification de scripts Superset
- Ajout/suppression de volumes Docker
```

**Status:** ⚠️ À ajouter dans `CONTRIBUTING.md`

---

### 4. `policy.md` (règle Cursor)

**Fichier:** `policy.md`

**Contenu:**
```markdown
# Règles de Protection - Cursor AI

## Fichiers protégés

Les fichiers suivants nécessitent une **validation humaine explicite** avant toute modification:

### Liste des fichiers protégés

1. `.env` - Variables d'environnement
2. `docker-compose.yml` - Configuration Docker
3. `docker-compose.*.yml` - Toutes les variantes
4. `superset_config.py` - Configuration Superset (si présent)
5. `superset/scripts/*.py` - Scripts de configuration

### Règles d'interaction

#### AVANT de modifier un fichier protégé:

1. **Alerter l'utilisateur** de l'impact potentiel
2. **Expliquer** ce qui va changer
3. **Demander confirmation explicite** avant modification
4. **Suggérer un backup** si approprié

#### JAMAI S:

- Modifier `SUPERSET_SECRET_KEY` sans confirmation explicite
- Supprimer des volumes Docker sans backup
- Changer la configuration Docker sans explication
- Commit automatique de fichiers `.env` avec secrets

#### TOUJOURS:

- Masquer les secrets dans les sorties (4 premiers + 4 derniers caractères)
- Proposer des alternatives moins risquées
- Documenter les changements dans les rapports
- Suggérer des tests avant déploiement
```

**Status:** ⚠️ À créer dans la racine du projet

---

## 🔒 MODIFICATIONS DOCKER-COMPOSE

### Commentaire ajouté (à faire manuellement)

Dans `docker-compose.yml`, ajouter:

```yaml
services:
  superset:
    # ⚠️ NE PAS CHANGER LA SUPERSET_SECRET_KEY EN PRODUCTION
    # Si modifiée, toutes les connexions DB deviennent non déchiffrables
    # Voir ops/SECRETS.md pour plus d'informations
    environment:
      - SUPERSET_SECRET_KEY=${SUPERSET_SECRET_KEY}
```

**Status:** ⚠️ À ajouter manuellement

---

## ✅ CHECKLIST DE VERRouillage

- [ ] `.env.example` créé (sans secrets)
- [ ] `ops/SECRETS.md` créé avec instructions
- [ ] Section "Fichiers protégés" ajoutée dans `CONTRIBUTING.md`
- [ ] `policy.md` créé avec règles Cursor
- [ ] Commentaire ajouté dans `docker-compose.yml`
- [ ] `.env` ajouté dans `.gitignore` (si pas déjà fait)
- [ ] `docker-compose.yml` vérifié pour absence de secrets en clair

---

## 📋 RÉSUMÉ

### Fichiers à créer

1. ✅ `.env.example` - Template sans secrets
2. ✅ `ops/SECRETS.md` - Documentation des secrets
3. ✅ `policy.md` - Règles Cursor AI
4. ⚠️ Section dans `CONTRIBUTING.md` - À ajouter manuellement
5. ⚠️ Commentaire dans `docker-compose.yml` - À ajouter manuellement

### Protection contre récidive

✅ **Documentation créée** pour éviter les modifications accidentelles
✅ **Règles Cursor** définies pour alerter avant modifications
⚠️ **Actions manuelles requises** pour compléter le verrouillage

---

**Date de génération:** 2025-11-04 21:35:00 America/Toronto
**Status:** ✅ Partiellement complet - Actions manuelles requises
