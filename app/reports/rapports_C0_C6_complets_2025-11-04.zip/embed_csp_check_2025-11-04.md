# VÉRIFICATION EMBED & HEADERS - 2025-11-04
# PROMPT C5: Vérif embed & headers (après DB rétablie)

## 🧪 TEST DES EN-TÊTES HTTP

### Méthode de test

**Commande:**
```bash
curl -sI http://localhost:8088/embedded/<UUID_DASHBOARD>
```

**À tester:** Après avoir identifié l'UUID d'un dashboard existant.

---

## 📊 EN-TÊTES À VÉRIFIER

### En-têtes de sécurité critiques

| En-tête | Valeur attendue | Impact |
|---------|----------------|--------|
| `X-Frame-Options` | `SAMEORIGIN` ou absent | ❌ `DENY` bloque l'embedding |
| `Content-Security-Policy` | `frame-ancestors http://localhost:*` | ✅ Autorise l'embedding |
| `Access-Control-Allow-Origin` | `*` ou domaine Tabler | ✅ Autorise les requêtes CORS |

---

## ⚠️ STATUS: À TESTER

### Action requise

1. **Identifier un dashboard UUID:**
   - Accéder à Superset: http://localhost:8088
   - Ouvrir un dashboard
   - Extraire l'UUID de l'URL: `/superset/dashboard/<UUID>/`

2. **Tester les en-têtes:**
   ```powershell
   curl -sI http://localhost:8088/embedded/<UUID>
   ```

3. **Vérifier les résultats:**
   - Si `X-Frame-Options: DENY` → **Bloque l'embedding**
   - Si `frame-ancestors` absent dans CSP → **Bloque l'embedding**
   - Si tous les en-têtes OK → ✅ **Embedding possible**

---

## 🔧 CORRECTION NÉCESSAIRE (si non conforme)

### Modifier `superset_config.py` dans le container

Si les en-têtes bloquent l'embedding, ajouter dans `/app/superset/config.py`:

```python
# Autoriser l'embedding
TALISMAN_ENABLED = True
TALISMAN_CONFIG = {
    'content_security_policy': {
        'default-src': "'self'",
        'script-src': "'self' 'unsafe-inline' 'unsafe-eval'",
        'style-src': "'self' 'unsafe-inline'",
        'img-src': "'self' data: https:",
        'frame-ancestors': "'self' http://localhost:*"
    },
    'frame_options': 'SAMEORIGIN'
}
```

**Note:** Cette modification doit être faite dans l'image Docker ou via un volume monté.

---

**Date de génération:** 2025-11-04 21:30:00 America/Toronto
**Status:** ⚠️ À tester après restauration des connexions DB
